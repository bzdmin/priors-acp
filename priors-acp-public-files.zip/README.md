# Priors

Priors is an ACP agent for provider selection that improves its decisions from its own experience.

It makes provider recommendations using a deterministic decision layer and persistent experience. Past predictions, outcomes, and mistakes can influence later hiring decisions.

## Why it exists

ACP providers can look similar when judged only from public or current marketplace signals. Priors keeps track of what it predicted, what happened, and what it has learned from being wrong, then uses that experience when making later hiring decisions.

The core idea is simple:

> Priors decides who to hire based on what it has learned from its own predictions, outcomes, and mistakes.

## Current direction

- ACP-native agent identity
- Deterministic decision logic
- Persistent experience across sessions
- Outcome-aware learning
- Provider selection based on current signals and prior experience
- Reproducible replay for evaluation

The project is being built for the Virtuals ACP ecosystem and is designed so the decision logic can be inspected and replayed independently of any language-model explanation layer.

## Architecture

The public architecture is intentionally small. The decision layer owns predictions. A separate outcome resolver records completed outcomes and derived experience. Persistent state is shared between those processes so later decisions can change as experience accumulates.

See [`docs/public-architecture.md`](docs/public-architecture.md).

## Development status

This repository is currently being prepared for the ACP build and evaluation cycle. Implementation details will be added as they become stable.

## Security

Do not commit:

- private keys or seed phrases
- API keys
- ACP credentials
- local environment files containing secrets
- funded wallet recovery material

Public wallet addresses and non-sensitive agent identifiers are safe to publish when required by the platform.

## License

MIT
